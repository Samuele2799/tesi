package it.unirc.tesi.beans.fornitore;

public class Recapito {

}
